package proyecto;

public abstract class User {
    private String name;
    private String email;

    // Constructor
    public User(String name, String email) {
        this.name = name;
        this.email = email;
    }

    // Métodos getters y setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Método toString que es sobrescrito en las clases hijas
    @Override
    public String toString() {
        return "Name: " + name + ", Email: " + email;
    }
}
